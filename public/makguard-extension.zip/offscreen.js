let mediaStream = null
let mediaRecorder = null
let activeTabId = null

async function acquireTabStream(streamId) {
  const attempts = [
    { audio: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId }, video: false },
    {
      audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
      video: false,
    },
  ]
  for (const constraints of attempts) {
    try {
      return await navigator.mediaDevices.getUserMedia(constraints)
    } catch {
      /* try next */
    }
  }
  throw new Error('offscreen tab audio failed')
}

function pickMimeType() {
  for (const t of ['audio/webm;codecs=opus', 'audio/webm']) {
    if (MediaRecorder.isTypeSupported(t)) return t
  }
  return ''
}

async function startTabAudio(streamId, tabId) {
  stopTabAudio()
  activeTabId = tabId
  console.log('[MakGuard offscreen] Starting tab audio for tab', tabId)
  mediaStream = await acquireTabStream(streamId)
  const mimeType = pickMimeType()
  mediaRecorder = new MediaRecorder(mediaStream, mimeType ? { mimeType } : {})

  mediaRecorder.ondataavailable = (event) => {
    if (!event.data?.size || activeTabId == null) return
    const reader = new FileReader()
    reader.onloadend = () => {
      const audio_data = reader.result
      if (typeof audio_data !== 'string') return
      chrome.runtime.sendMessage({
        type: 'MAKguard_OFFSCREEN_AUDIO_CHUNK',
        payload: { tabId: activeTabId, audio_data, blobSize: event.data.size },
      })
    }
    reader.readAsDataURL(event.data)
  }

  mediaRecorder.start(3500)
}

function stopTabAudio() {
  activeTabId = null
  if (mediaRecorder) {
    try {
      if (mediaRecorder.state !== 'inactive') mediaRecorder.stop()
    } catch {
      /* ignore */
    }
    mediaRecorder = null
  }
  if (mediaStream) {
    mediaStream.getTracks().forEach((t) => t.stop())
    mediaStream = null
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'MAKguard_OFFSCREEN_START_TAB_AUDIO') {
    const { streamId, tabId } = message.payload ?? {}
    startTabAudio(streamId, tabId)
      .then(() => {
        console.log('[MakGuard offscreen] Tab audio recording started')
        sendResponse({ ok: true })
      })
      .catch((err) => {
        console.warn('[MakGuard offscreen] Tab audio failed:', err)
        sendResponse({ ok: false, error: String(err?.message ?? err) })
      })
    return true
  }
  if (message.type === 'MAKguard_OFFSCREEN_STOP_TAB_AUDIO') {
    stopTabAudio()
    sendResponse({ ok: true })
    return true
  }
  return false
})
